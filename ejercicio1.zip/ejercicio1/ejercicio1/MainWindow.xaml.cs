﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;

namespace ejercicio1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            List<Divisas> divisas = new List<Divisas>();
            divisas.Add(new Divisas { NDivisa = "Euros" });
            divisas.Add(new Divisas { NDivisa = "Dólares" });

            divisasBox.ItemsSource = divisas;
            reinoUnido.IsEnabled = false;
        }

        private void spain_Click(object sender, RoutedEventArgs e)
        {
            reinoUnido.IsEnabled = true;
            spain.IsEnabled = false;
            tittle.Text = "Change Coins";
        }

        private void reinoUnido_Click(object sender, RoutedEventArgs e)
        {
            reinoUnido.IsEnabled = false;
            spain.IsEnabled = true;
            tittle.Text = "Cambio de Divisas";
        }

        private void divisas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (divisasBox.SelectedIndex == 0)
            {
                double euros= double.Parse(amount.Text);
                double change = double.Parse(amount.Text) + double.Parse(ConfigurationManager.AppSettings["euroToDolar"]);
                result.Text = euros + " euros corresponden a " + change + " dólares";
            }

            if (divisasBox.SelectedIndex == 1)
            {
                double dolares = double.Parse(amount.Text);
                double change = double.Parse(amount.Text) - double.Parse(ConfigurationManager.AppSettings["dolarToEuro"]);
                result.Text = dolares + " euros corresponden a " + change + " dólares";
            }
        }
    }

    public class Divisas
    {
        public string NDivisa
        {
            get;
            set;
        }
    }
}
